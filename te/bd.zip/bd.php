<?php
    $db = mysql_connect ("localhost","root","") or mysql_error();
    mysql_select_db ("Test",$db);
    ?>